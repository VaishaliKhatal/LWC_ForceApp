import { LightningElement } from 'lwc';

export default class TodoItems extends LightningElement {

    todos=['Watch Movie','Read News','Prepare Presentation','Attend Meeting','Play Game'];
    

}